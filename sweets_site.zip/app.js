// Simple SPA logic with localStorage persistence
const state = {
  items: JSON.parse(localStorage.getItem('sweets_items')||'[]'),
  reviews: JSON.parse(localStorage.getItem('sweets_reviews')||'[]'),
  cart: JSON.parse(localStorage.getItem('sweets_cart')||'[]'),
};

function $(sel, root=document) { return root.querySelector(sel) }
function $all(sel, root=document) { return Array.from(root.querySelectorAll(sel)) }

function save() {
  localStorage.setItem('sweets_items', JSON.stringify(state.items));
  localStorage.setItem('sweets_reviews', JSON.stringify(state.reviews));
  localStorage.setItem('sweets_cart', JSON.stringify(state.cart));
}

function renderCatalog(targetId){
  const container = $(targetId);
  container.innerHTML = '';
  if(state.items.length===0){
    container.innerHTML = '<div class="card">Каталог пуст. Добавь товар в шапке.</div>';
    return;
  }
  state.items.forEach((it, idx)=>{
    const card = document.createElement('div'); card.className='card';
    card.innerHTML = `
      <img src="${it.image}" alt="${it.title}">
      <div>
        <h4 style="margin:0 0 6px 0">${it.title}</h4>
        <div style="color:var(--muted);font-size:13px">${it.desc}</div>
      </div>
      <div class="meta">
        <div style="font-weight:700">${it.price || '—'} ₽</div>
        <div>
          <button data-idx="${idx}" class="add-cart">В корзину</button>
        </div>
      </div>`;
    container.appendChild(card);
  });
  $all('.add-cart', container).forEach(btn=>{
    btn.addEventListener('click', e=>{
      const idx = +e.currentTarget.dataset.idx;
      const it = state.items[idx];
      state.cart.push(Object.assign({qty:1}, it));
      save();
      renderCart();
      alert('Добавлено в корзину');
    })
  })
}

function renderReviews(){
  const root = $('#reviewsList');
  root.innerHTML = '';
  if(state.reviews.length===0){ root.innerHTML='<div class="card">Нет отзывов</div>'; return; }
  state.reviews.slice().reverse().forEach(r=>{
    const d = document.createElement('div'); d.className='review';
    d.innerHTML = `<strong>${r.name}</strong><div style="color:var(--muted);margin-top:6px">${r.text}</div>`;
    root.appendChild(d);
  });
}

function renderCart(){
  const root = $('#cartList');
  root.innerHTML = '';
  if(state.cart.length===0){ root.innerHTML='<div class="card">Корзина пуста</div>'; $('#cartTotal').textContent='0 ₽'; return; }
  let total = 0;
  state.cart.forEach((c, i)=>{
    const el = document.createElement('div'); el.className='cart-item';
    el.innerHTML = `
      <img src="${c.image}" alt="${c.title}">
      <div style="flex:1">
        <div style="font-weight:700">${c.title}</div>
        <div style="color:var(--muted);font-size:13px">${c.desc}</div>
      </div>
      <div style="text-align:right">
        <div>${c.price || '—'} ₽</div>
        <div style="margin-top:8px">
          <button data-i="${i}" class="remove">Убрать</button>
        </div>
      </div>
    `;
    root.appendChild(el);
    total += Number(c.price||0);
  });
  $all('.remove', root).forEach(b=>{
    b.addEventListener('click', e=>{
      const i = +e.currentTarget.dataset.i;
      state.cart.splice(i,1);
      save(); renderCart();
    })
  });
  $('#cartTotal').textContent = total + ' ₽';
}

function initUI(){
  // header icon routing
  $all('.icon-btn').forEach(b=>{
    b.addEventListener('click', (e)=>{
      const r = e.currentTarget.getAttribute('data-route');
      location.hash = r;
    })
  });

  // file preview
  const imgIn = $('#imageInput');
  imgIn.addEventListener('change', (e)=>{
    const f = e.target.files[0];
    if(!f) return;
    const reader = new FileReader();
    reader.onload = ev => {
      $('#previewImg').src = ev.target.result;
      $('#preview').classList.remove('empty');
      $('#previewTitle').textContent = $('#titleInput').value || '';
      $('#previewDesc').textContent = $('#descInput').value || '';
    };
    reader.readAsDataURL(f);
  });

  // live preview for inputs
  $('#titleInput').addEventListener('input', ()=> $('#previewTitle').textContent = $('#titleInput').value);
  $('#descInput').addEventListener('input', ()=> $('#previewDesc').textContent = $('#descInput').value);

  $('#addItem').addEventListener('click', ()=>{
    const img = $('#previewImg').src || '';
    const title = $('#titleInput').value.trim() || 'Без названия';
    const desc = $('#descInput').value.trim() || '';
    const price = prompt('Укажи цену в ₽ (только цифры)', '200') || '';
    const item = {image: img, title, desc, price};
    state.items.push(item);
    save();
    // clear inputs
    $('#titleInput').value=''; $('#descInput').value=''; $('#previewImg').src=''; $('#preview').classList.add('empty');
    renderCatalog('#catalog');
    renderCatalog('#catalogPage');
    alert('Товар добавлен в каталог');
  });

  // reviews
  $('#reviewForm').addEventListener('submit', (e)=>{
    e.preventDefault();
    const name = $('#revName').value.trim()||'Аноним';
    const text = $('#revText').value.trim();
    if(!text) return;
    state.reviews.push({name, text, date:Date.now()});
    save(); renderReviews();
    $('#revName').value=''; $('#revText').value='';
  });

  // clear cart
  $('#clearCart').addEventListener('click', ()=>{
    if(confirm('Очистить корзину?')){ state.cart=[]; save(); renderCart(); }
  });

  // routing
  function route(){
    const h = location.hash || '#/';
    $all('.view').forEach(v=>v.classList.remove('active'));
    if(h.startsWith('#/catalog')) $('#catalogView').classList.add('active');
    else if(h.startsWith('#/reviews')) $('#reviewsView').classList.add('active');
    else if(h.startsWith('#/cart')) $('#cartView').classList.add('active');
    else document.getElementById('home').classList.add('active');
  }
  window.addEventListener('hashchange', route);
  route();

  // render initial
  renderCatalog('#catalog');
  renderCatalog('#catalogPage');
  renderReviews();
  renderCart();

  // footer year
  document.getElementById('year').textContent = new Date().getFullYear();
}

document.addEventListener('DOMContentLoaded', initUI);
